import React from 'react'
import '../../style/mypage/mypage.css'
import { Route, Routes } from 'react-router-dom'
import MypageNav from './mypage-main/MypageNav'
import OrderApp from './order/OrderApp'
import WishApp from './wish/WishApp'
import Reserves from './cupon,reserves,benefit/Reserves'
import Cupon from './cupon,reserves,benefit/Cupon'
import Benefit from './cupon,reserves,benefit/Benefit'
import Userinformation from './userInformation/Userinformation'
import ReviewWrite from './my-review/ReviewWrite'
import Mypage from './mypage-main/Mypage'
import MypageUp from './mypage-main/MypageUp'
import ReviewList from './my-review/MyReview'
import ReviewUpdate from './my-review/ReviewUpdate'
import MyQnA from './my-qna/MyQnA'


function MyPageMain() {
  return (
    <div className='mypageTotalContainer'>
      <div className='mypageHeader'>
      <MypageUp/>
      </div>
      <div className='mypageNavRoutesBox'>
      <MypageNav/>
      <Routes>
        <Route path='/' element={<Mypage/>}/> 
        <Route path='/orderApp' element={<OrderApp />}/> 
        <Route path='/my-review' element={<ReviewList />}/>
        <Route path='/wishlist' element={<WishApp />}/>
        <Route path='/my-qna' element={<MyQnA />}/>
        <Route path='/mileage' element={<Reserves />}/>
        <Route path='/coupon' element={<Cupon />}/>
        <Route path='/membership' element={<Benefit />}/>
        <Route path='/userinformation' element={<Userinformation />}/>
        <Route path='/my-review/write/:orderDetailId/:pName' element={<ReviewWrite />}/>
        <Route path='/my-review/update/:reviewId' element={<ReviewUpdate />}/>
      </Routes>
      </div>
    </div>
  )
}

export default MyPageMain